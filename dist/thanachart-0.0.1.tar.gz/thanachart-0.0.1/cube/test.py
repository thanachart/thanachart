
def hello():
    print('Hello I\'m a function from my_module2')