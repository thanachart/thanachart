
print('hello world')